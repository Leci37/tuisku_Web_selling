# MANIFEST · edgefolio-design-2026-10-06

- **Export date:** 2026-10-06
- **Tool:** edgefolio, repository `Leci37/tuisku_Web_selling`, branch `_ztool_dev`
- **Files:** 85, all under `design_handoff_edgefolio_storefront/` in the zip

The names are stable from export to export. The names that `tools/design_update.py` reads are unchanged. The user's `uploads/` folder is not included.

## Root

- `FLUJO_USUARIO.md`: User flow in Spanish for screens 1–9, each marked same / changed / new / removed, with states and the phone differences
- `MANIFEST.md`: This list of files
- `PR_DESCRIPTION.md`: Work steps (its branch and pull-request lines are replaced by README.md)
- `README.md`: Read me first: tool, file names, prompt for Claude Code, what changed since the previous export (by screen 1–9), facts, screens, core vs tool, design tokens
- `STATUS.md`: Status per screen 1–9 (final, in progress or sketch), versions/, sample data and open questions
- `texts.json`: Every interface text with its key: tool (storefront.ui.json), core, tree, indicators, fixed names, sample catalogue texts

## docs/

- `docs/IMPLEMENTATION-v7.md`: Technical implementation guide for v7
- `docs/USER-FLOW-v7.md`: English user flow, with what is simulated (§17), the fixes of 6 Oct 2026 (§18) and open points (§19)
- `docs/catalogue-updates.md`: How the catalogue is refreshed
- `docs/img/shop_cart.png`: Screenshot used by the repository README
- `docs/img/shop_catalogue.png`: Screenshot used by the repository README
- `docs/img/shop_thankyou.png`: Screenshot used by the repository README

## offline/

- `offline/storefront-offline.html`: Storefront v7 in one self-contained file; opens with a double click and no internet

## prototype/ · current screens and runtime

- `prototype/Storefront v7.dc.html`: Current design: screens 1–3 and 5–9 (Lite, Pro, strategy page, cart and checkout, free dialog, thank you, My strategies, phone)
- `prototype/Strategy Tree.dc.html`: Current design: screen 4, How it decides (embedded in the strategy page)
- `prototype/support.js`: Design Component runtime; loads React, ReactDOM and Babel from prototype/vendor/

## prototype/ · texts and data

- `prototype/i18n/storefront.ui.json`: Tool texts in 8 languages; no key repeats a core key
- `prototype/trees/features.json`: Indicator names and explanations (es/en)
- `prototype/trees/previews.json`: List of the Pine previews the tree viewer parses
- `prototype/trees/ui.json`: Tree viewer texts in 8 languages
- `prototype/zlecitool_core/i18n/common.json`: Copy of the core shared texts, for the prototype

## prototype/ · images, icons, logos

- `prototype/brand/tuisku-logo-192.png`: tuisku logo 192 (not used by any screen)
- `prototype/brand/tuisku-logo-96.png`: tuisku logo 96 (not used by any screen)
- `prototype/brand/tuisku-logo-white-96.png`: tuisku logo white-96 (not used by any screen)
- `prototype/storefront/assets/charts/AAPL_1Day_1C00_ac87f0dc_candel.png`: TradingView candle chart, AAPL · 1C00 (1Day)
- `prototype/storefront/assets/charts/AAPL_1Day_1C00_ac87f0dc_profit.png`: TradingView profit curve, AAPL · 1C00 (1Day)
- `prototype/storefront/assets/charts/ADBE_1Day_1T00_751f3295_candel.png`: TradingView candle chart, ADBE · 1T00 (1Day)
- `prototype/storefront/assets/charts/ADBE_1Day_1T00_751f3295_profit.png`: TradingView profit curve, ADBE · 1T00 (1Day)
- `prototype/storefront/assets/charts/AMZN_1Day_1BOL_9d10c25f_candel.png`: TradingView candle chart, AMZN · 1BOL (1Day)
- `prototype/storefront/assets/charts/AMZN_1Day_1BOL_9d10c25f_profit.png`: TradingView profit curve, AMZN · 1BOL (1Day)
- `prototype/storefront/assets/charts/AMZN_1Day_1T00_912096cc_candel.png`: TradingView candle chart, AMZN · 1T00 (1Day)
- `prototype/storefront/assets/charts/AMZN_1Day_1T00_912096cc_profit.png`: TradingView profit curve, AMZN · 1T00 (1Day)
- `prototype/storefront/assets/charts/BTCUSDT_1Day_1BOL_4166b2d5_candel.png`: TradingView candle chart, BTCUSDT · 1BOL (1Day)
- `prototype/storefront/assets/charts/BTCUSDT_1Day_1BOL_4166b2d5_profit.png`: TradingView profit curve, BTCUSDT · 1BOL (1Day)
- `prototype/storefront/assets/charts/ETHUSDT_1Day_1T00_9cc24d8a_candel.png`: TradingView candle chart, ETHUSDT · 1T00 (1Day)
- `prototype/storefront/assets/charts/ETHUSDT_1Day_1T00_9cc24d8a_profit.png`: TradingView profit curve, ETHUSDT · 1T00 (1Day)
- `prototype/storefront/assets/charts/NVDA_1Day_1M00_14639a7a_candel.png`: TradingView candle chart, NVDA · 1M00 (1Day)
- `prototype/storefront/assets/charts/NVDA_1Day_1M00_14639a7a_profit.png`: TradingView profit curve, NVDA · 1M00 (1Day)
- `prototype/storefront/assets/charts/NVDA_1Day_1S00_1b1cceca_candel.png`: TradingView candle chart, NVDA · 1S00 (1Day)
- `prototype/storefront/assets/charts/NVDA_1Day_1S00_1b1cceca_profit.png`: TradingView profit curve, NVDA · 1S00 (1Day)
- `prototype/storefront/assets/icons/AAPL_big.svg`: Ticker icon AAPL
- `prototype/storefront/assets/icons/ADBE_big.svg`: Ticker icon ADBE
- `prototype/storefront/assets/icons/AMZN_big.svg`: Ticker icon AMZN
- `prototype/storefront/assets/icons/BTC+USDT_big.svg`: Ticker icon BTC/USDT
- `prototype/storefront/assets/icons/CRSR_big.svg`: Ticker icon CRSR
- `prototype/storefront/assets/icons/ETH+USDT_big.svg`: Ticker icon ETH/USDT
- `prototype/storefront/assets/icons/NVDA_big.svg`: Ticker icon NVDA
- `prototype/storefront/assets/icons/TW_ICO.svg`: TradingView icon
- `prototype/storefront/assets/icons/a_logo_paypal.png`: PayPal logo
- `prototype/storefront/assets/icons/a_logo_tuisku_azulLetras.png`: tuisku logo, blue letters (not used by any screen)
- `prototype/zlecitool_core/ui/static/brand/tuisku-mark-128.png`: tuisku mark from the core (used by versions/ Storefront Redesign, v2, v3)

## prototype/ · Pine previews

- `prototype/storefront/assets/previews/Q1JTUiAtIDFEYXkgLSAxTUFDIC0gZmZlZGMwMTU.pine`: Free Pine preview of CRSR - 1Day - 1MAC - ffedc015 (paid part cut)
- `prototype/storefront/assets/previews/Q1JTUiAtIDFEYXkgLSAxVDAwIC0gM2Y0ZWYwMGY.pine`: Free Pine preview of CRSR - 1Day - 1T00 - 3f4ef00f (paid part cut)
- `prototype/storefront/assets/previews/Q1JTUiAtIDFEYXkgLSAxVjAwIC0gMTVlYTNmMjI.pine`: Free Pine preview of CRSR - 1Day - 1V00 - 15ea3f22 (paid part cut)
- `prototype/storefront/assets/previews/QU1aTiAtIDFEYXkgLSAxQk9MIC0gOWQxMGMyNWY.pine`: Free Pine preview of AMZN - 1Day - 1BOL - 9d10c25f (paid part cut)
- `prototype/storefront/assets/previews/QU1aTiAtIDFEYXkgLSAxVDAwIC0gOTEyMDk2Y2M.pine`: Free Pine preview of AMZN - 1Day - 1T00 - 912096cc (paid part cut)
- `prototype/storefront/assets/previews/QUFQTCAtIDFEYXkgLSAxQzAwIC0gYWM4N2YwZGM.pine`: Free Pine preview of AAPL - 1Day - 1C00 - ac87f0dc (paid part cut)
- `prototype/storefront/assets/previews/QURCRSAtIDFEYXkgLSAxVDAwIC0gNzUxZjMyOTU.pine`: Free Pine preview of ADBE - 1Day - 1T00 - 751f3295 (paid part cut)
- `prototype/storefront/assets/previews/QlRDVVNEVCAtIDFEYXkgLSAxQk9MIC0gNDE2NmIyZDU.pine`: Free Pine preview of BTCUSDT - 1Day - 1BOL - 4166b2d5 (paid part cut)
- `prototype/storefront/assets/previews/RVRIVVNEVCAtIDFEYXkgLSAxVDAwIC0gOWNjMjRkOGE.pine`: Free Pine preview of ETHUSDT - 1Day - 1T00 - 9cc24d8a (paid part cut)
- `prototype/storefront/assets/previews/TlZEQSAtIDFEYXkgLSAxTTAwIC0gMTQ2MzlhN2E.pine`: Free Pine preview of NVDA - 1Day - 1M00 - 14639a7a (paid part cut)
- `prototype/storefront/assets/previews/TlZEQSAtIDFEYXkgLSAxUzAwIC0gMWIxY2NlY2E.pine`: Free Pine preview of NVDA - 1Day - 1S00 - 1b1cceca (paid part cut)

## prototype/ · fonts

- `prototype/zlecitool_core/ui/static/fonts/Ubuntu-400-latin.woff2`: Ubuntu 400 font (core)
- `prototype/zlecitool_core/ui/static/fonts/Ubuntu-500-latin.woff2`: Ubuntu 500 font (core)
- `prototype/zlecitool_core/ui/static/fonts/Ubuntu-700-latin.woff2`: Ubuntu 700 font (core)

## prototype/vendor/ · local copies of outside libraries

- `prototype/vendor/babel/babel.min.js`: Babel standalone 7.29.0 (local copy, SRI checked)
- `prototype/vendor/fontawesome/css/all.min.css`: Font Awesome 6.0.0-beta3 stylesheet (local copy)
- `prototype/vendor/fontawesome/webfonts/fa-brands-400.ttf`: Font Awesome webfont brands-400 (ttf)
- `prototype/vendor/fontawesome/webfonts/fa-brands-400.woff2`: Font Awesome webfont brands-400 (woff2)
- `prototype/vendor/fontawesome/webfonts/fa-regular-400.ttf`: Font Awesome webfont regular-400 (ttf)
- `prototype/vendor/fontawesome/webfonts/fa-regular-400.woff2`: Font Awesome webfont regular-400 (woff2)
- `prototype/vendor/fontawesome/webfonts/fa-solid-900.ttf`: Font Awesome webfont solid-900 (ttf)
- `prototype/vendor/fontawesome/webfonts/fa-solid-900.woff2`: Font Awesome webfont solid-900 (woff2)
- `prototype/vendor/fontawesome/webfonts/fa-v4compatibility.ttf`: Font Awesome webfont v4compatibility (ttf)
- `prototype/vendor/fontawesome/webfonts/fa-v4compatibility.woff2`: Font Awesome webfont v4compatibility (woff2)
- `prototype/vendor/react/react-dom.production.min.js`: ReactDOM 18.3.1 (local copy, SRI checked)
- `prototype/vendor/react/react.production.min.js`: React 18.3.1 (local copy, SRI checked)

## versions/ · earlier versions and sketches (reference only)

- `versions/Improvements Lab.dc.html`: Sketch: the 10 improvement ideas
- `versions/Storefront Redesign.dc.html`: Sketch: five directions 1a–1e and "Today" (the shop before the redesign)
- `versions/Storefront v2.dc.html`: Earlier version v2 (replaced by v7)
- `versions/Storefront v3.dc.html`: Earlier version v3 (replaced by v7)
- `versions/Storefront v4.dc.html`: Earlier version v4 (replaced by v7)
- `versions/Storefront v5.dc.html`: Earlier version v5 (replaced by v7)
- `versions/Storefront v6.dc.html`: Earlier version v6 (replaced by v7)
- `versions/Tree Styles.dc.html`: Sketch: three display options for How it decides
